cv_body = function(th_val, h, k0, y_train, hs_train, mMatArr_valid){
  th = rep(th_val, k0)
  p = dim(y_train)[1]
  thMat = 1*(hs_train >= rep(th, each = p^2))
  mMatArr_train = lag_cov_int(y_train, thMat, h, k0)
  apply((mMatArr_train - mMatArr_valid), 3, norm, '2')
}

cv_single = function(y_train, y_valid, h, k0, t_seq = seq(0.2, 3, 0.2)){
  hs_train = lag_cov_hs(y_train, h, k0)
  p = dim(y_train)[1]

  mMatArr_valid = lag_cov_int(y_valid, array(1, c(p, p, k0)), h, k0)
  resCV = sapply(t_seq, cv_body, h = h, k0 = k0, y_train = y_train,
                 hs_train = hs_train, mMatArr_valid = mMatArr_valid)
  t_seq[apply(resCV, 1, which.min)]
}

analyzeM = function(mMatArr, Q, r) {
  ## threshold on each slice of mMatArr
  p = dim(mMatArr)[1]
  mMat = apply(mMatArr, c(1,2), sum)
  mEig = eigen(mMat)
  val = mEig$values
  vec = mEig$vectors

  R = p/2
  ratio = val[2:p] / val[1:p-1]
  rhat = which.min(ratio[1:R])
  hatA = vec[, 1:rhat]
  temp = Q %*% t(Q) %*% hatA %*% t(hatA)
  trc = sum(diag(temp))
  meas = sqrt(1 - trc / max(r, rhat))
  return(list(rhat = rhat, dist = meas, eigval = val, hatA = hatA))
}

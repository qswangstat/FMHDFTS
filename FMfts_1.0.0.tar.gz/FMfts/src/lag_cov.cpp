#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

//' @description \loadmathjax 
//' this function is designed to compute Hilbert-Schmidt(HS) norm of lag covariance
//' @title Hilbert-Schmidt(HS) norm of lag covariance
//' @param y a cube of p*t*n-dim, containing functional time series vector observed at t time points.
//'        n is the sample size.
//' @param h gap between consecutive time points
//' @param k0 the maximum lag
//' @return a cube of p*p*k0-dim, each slice being a p*p matrix of HS norm
//' @details HS norm of function \mjseqn{f(x,y)\in L^2([0,1])} is defined by
//'         \mjsdeqn{\|f\|_{HS}:=\sqrt{\int\int f^2(x,y)dxdy};}
//'         we apply trapezoid rule to compute integral, that is 
//'         \mjsdeqn{\int_a^b\int_c^d f(x, y)dydx = \frac{h^2}{4}[f(a,c)+f(b,c)+f(a,d)+f(b,d)+2\sum_i f(x_i, c)+2\sum_i f(x_i, d) + 2\sum_j f(a,y_j) + 2\sum_j f(b,y_j)+ 4\sum_j\sum_i f(x_i,y_j)].}
//'         the lag-k covariance is given by
//'         \mjsdeqn{\Sigma_k = \frac{1}{n-k}\sum_{i=k+1}^{n}y_i(u)y_{i-k}(v)^T}
// [[Rcpp::export]]
arma::cube lag_cov_hs(arma::cube y, double h, int k0){
  //  y is (p * len * n)-dim array created in R
  int p = y.n_rows, len = y.n_cols, n = y.n_slices;
  cube HSnorm(p, p, k0);
  vec yumean(p), yvmean(p); // store mean at time points u, v
  int idinfo;
  double trapcoef; // set coefficients in trapezoid rule
  mat sMat(p, p);
  for(int k = 1; k <= k0; ++k){
    mat sHSnorm(p,p, fill::zeros);
    mat yuk(p, n-k), yvk(p, n-k);
    for(int uid = 0; uid < len; ++uid){
      yuk = y(span(), span(uid), span(k,n-1)); // sample index (k+1):n 
      yumean = mean(y.col(uid), 2);
      
      yuk.each_col() -= yumean; // centered
      for(int vid = 0; vid < len; ++vid){
        
        yvmean = mean(y.col(vid), 2); 
        
        idinfo = int(uid == 0 | uid == len-1) + int(vid == 0 | vid == len-1);
        trapcoef = 1.0 / (idinfo * 2 + int(idinfo == 0)); // 1/4, 1/2, or 1
        
        yvk = y(span(), span(vid), span(0,n-k-1)); // sample index 1:(n-k) 
        
        yvk.each_col() -= yvmean;// centered
        
        sMat = yuk * yvk.t() / (n-k);
        sHSnorm += (sMat % sMat) * pow(h, 2) * trapcoef; // element-wise square of sMat
      }
    }
    HSnorm.slice(k-1) = sqrt(sHSnorm);
  }
  return HSnorm;
}

//' @description \loadmathjax 
//' this function is designed to compute M matrix
//' @title compute M matrix
//' @param y a cube of p*t*n-dim, containing functional time series vector observed at t time points.
//'        n is the sample size.
//' @param indArr is a cube of p*p*k0, containing indicator matrices. 
//'        These matrices are usually obtained by thresholding.
//' @param h gap between consecutive time points
//' @param k0 the maximum lag
//' @return a cube of p*p*k0 dim, the k-th slice being a p*p matrix 
//'         \mjsdeqn{\int\int \Sigma_k\Sigma_k^T}
//' @details we apply trapezoid rule to compute integral, that is 
//'         \mjsdeqn{\int_a^b\int_c^d f(x, y)dydx = \frac{h^2}{4}[f(a,c)+f(b,c)+f(a,d)+f(b,d)+2\sum_i f(x_i, c)+2\sum_i f(x_i, d) + 2\sum_j f(a,y_j) + 2\sum_j f(b,y_j)+ 4\sum_j\sum_i f(x_i,y_j)].}
//'         the lag-k covariance is given by
//'         \mjsdeqn{\Sigma_k = \frac{1}{n-k}\sum_{i=k+1}^{n}y_i(u)y_{i-k}(v)^T}
//'         
// [[Rcpp::export]]
arma::cube lag_cov_int(arma::cube y, arma::cube indArr, double h, int k0){
  //  y is (p * len * n)-dim array created in R
  int p = y.n_rows, len = y.n_cols, n = y.n_slices;
  cube mMatArr(p, p, k0);
  vec yumean(p), yvmean(p);
  int idinfo;
  double trapcoef;
  mat sMat(p, p), sigMat(p, p), indMat(p, p);
  for(int k = 1; k <= k0; ++k){
    indMat = indArr.slice(k-1);
    mat mMat(p, p, fill::zeros);
    mat yuk(p, n-k), yvk(p, n-k);
    for(int uid = 0; uid < len; ++uid){
      yuk = y(span(), span(uid), span(k,n-1));
      yumean = mean(y.col(uid), 2);
      
      yuk.each_col() -= yumean;
      for(int vid = 0; vid < len; ++vid){
        
        yvmean = mean(y.col(vid), 2);
        idinfo = int(uid == 0 | uid == len-1) + int(vid == 0 | vid == len-1);
        
        trapcoef = 1.0 / (idinfo * 2 + int(idinfo == 0));
        
        yvk = y(span(), span(vid), span(0,n-k-1));
        
        yvk.each_col() -= yvmean;
        
        sMat = (yuk * yvk.t()) % indMat / (n-k);
        sigMat = sMat * sMat.t();
        mMat += sigMat * pow(h, 2) * trapcoef;
      }
    }
    mMatArr.slice(k-1) = mMat;
  }
  return mMatArr;
}

// [[Rcpp::export]]
arma::cube lag_cov_int_double(arma::cube y, arma::cube indArr, double h, int k0){
  //  y is (p * len * n)-dim array created in R
  int p = y.n_rows, len = y.n_cols, n = y.n_slices;
  cube mMatArr(p, p, k0);
  vec yumean(p), yvmean(p);
  int idinfo;
  double trapcoef;
  mat sMat(p, p), indMat(p, p);
  for(int k = 1; k <= k0; ++k){
    indMat = indArr.slice(k-1);
    mat mMat(p, p, fill::zeros);
    mat yuk(p, n-k), yvk(p, n-k);
    for(int uid = 0; uid < len; ++uid){
      yuk = y(span(), span(uid), span(k,n-1));
      yumean = mean(y.col(uid), 2);
      
      yuk.each_col() -= yumean;
      for(int vid = 0; vid < len; ++vid){
        
        yvmean = mean(y.col(vid), 2);
        idinfo = int(uid == 0 | uid == len-1) + int(vid == 0 | vid == len-1);
        
        trapcoef = 1.0 / (idinfo * 2 + int(idinfo == 0));
        
        yvk = y(span(), span(vid), span(0,n-k-1));
        
        yvk.each_col() -= yvmean;
        
        sMat = (yuk * yvk.t()) % indMat / (n-k);
        mMat += sMat * pow(h, 2) * trapcoef;
      }
    }
    mMatArr.slice(k-1) = mMat;
  }
  return mMatArr;
}


// [[Rcpp::export]]
arma::cube lag_cov_int_single(arma::cube y, arma::cube indArr, double h, int k0){
  //  y is (p * len * n)-dim array created in R
  int p = y.n_rows, len = y.n_cols, n = y.n_slices;
  cube mMatArr(p, p, k0);
  vec yumean(p);
  int idinfo;
  double trapcoef;
  mat sMat(p, p), indMat(p, p);
  for(int k = 1; k <= k0; ++k){
    indMat = indArr.slice(k-1);
    mat mMat(p, p, fill::zeros);
    mat yuk(p, n-k), yuk2(p, n-k);
    for(int uid = 0; uid < len; ++uid){
      yuk = y(span(), span(uid), span(k,n-1));
      yuk2 = y(span(), span(uid), span(0,n-k-1));
      
      yumean = mean(y.col(uid), 2);
      
      yuk.each_col() -= yumean;
      yuk2.each_col() -= yumean;
      
      idinfo = int(uid == 0 | uid == len-1);
      trapcoef = 1.0 / (idinfo * 2 + int(idinfo == 0));
        
      sMat = (yuk * yuk2.t()) % indMat / (n-k);
      mMat += sMat * h * trapcoef;
    }
    mMatArr.slice(k-1) = mMat;
  }
  return mMatArr;
}

// [[Rcpp::export]]
arma::cube cv_diff(arma::cube y, arma::cube indArr, double h, int k0){
  //  y is (p * len * n)-dim array created in R
  int p = y.n_rows, len = y.n_cols, n = y.n_slices;
  cube diffArr(p, p, k0);
  vec yumean(p), yvmean(p);
  int idinfo;
  double trapcoef;
  mat sMat(p, p), indMat(p, p), diff_mat(p, p), diff_int(p, p);
  for(int k = 1; k <= k0; ++k){
    indMat = indArr.slice(k-1);
    mat yuk(p, n-k), yvk(p, n-k);
    for(int uid = 0; uid < len; ++uid){
      yuk = y(span(), span(uid), span(k,n-1));
      yumean = mean(y.col(uid), 2);
      
      yuk.each_col() -= yumean;
      for(int vid = 0; vid < len; ++vid){
        
        yvmean = mean(y.col(vid), 2);
        idinfo = int(uid == 0 | uid == len-1) + int(vid == 0 | vid == len-1);
        
        trapcoef = 1.0 / (idinfo * 2 + int(idinfo == 0));
        
        yvk = y(span(), span(vid), span(0,n-k-1));
        
        yvk.each_col() -= yvmean;
        
        sMat = (yuk * yvk.t()) / (n-k);
        diff_mat = sMat - sMat % indMat;
        diff_int += (diff_mat % diff_mat)* pow(h, 2) * trapcoef;
      }
    }
    diffArr.slice(k-1) = diff_int;
  }
  return diffArr;
}





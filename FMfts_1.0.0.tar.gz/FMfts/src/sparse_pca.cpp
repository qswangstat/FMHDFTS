#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

// [[Rcpp::export]]
arma::vec stlda(arma::mat B, arma::mat M, arma::vec x_0, 
                int s, int max_iter = 200, double tol = 1e-4){
  vec x_curr = x_0, x_prev = x_0;
  x_prev /= norm(x_prev);
  int n = x_0.n_elem;
  uvec index(n);
  
  mat eig_vec(size(B));
  vec eig_val(B.n_rows);
  eig_sym(eig_val, eig_vec, B);
  uvec ind = find(eig_val > 1e-2);
  mat B_sqrt_inv = eig_vec.cols(ind) * diagmat(1 / sqrt(eig_val(ind))) * eig_vec.cols(ind).t();
  
  mat C = B_sqrt_inv * M * B_sqrt_inv;
  
  for(int iter = 0; iter < max_iter; ++iter){
    if(iter == max_iter) break;
    x_curr = B_sqrt_inv * C * x_prev / norm(C * x_prev);
    index = sort_index(abs(x_curr));
    if(s < n) x_curr(index.subvec(0, n-s-1)).fill(0);
    else break;
    x_curr /= norm(x_curr);
    if(norm(x_curr - x_prev) < tol) break;
    x_prev = x_curr;
    
  }
  return x_curr;
}

// [[Rcpp::export]]
arma::mat gdefla(arma::mat M, arma::vec card){
  int r = card.n_elem, p = M.n_rows, s;
  double min_eigv;
  mat Ahat(p, r), B(p, p, fill::eye), Ip(p, p , fill::eye);
  mat Mhat = M, proj(p, p), temp(p, p);
  vec vhat(p), q(p), x_0;
  for(int i = 0; i < r; ++i){
    s = card.at(i);   
    x_0.randu(p);
    vhat = stlda(B, Mhat, x_0, s);
    q = B * vhat;
    proj = Ip - q * q.t();
    Mhat = proj * Mhat * proj;
    B = B * proj;
    Ahat.col(i) = vhat / norm(vhat);
  }
  return Ahat;
}
